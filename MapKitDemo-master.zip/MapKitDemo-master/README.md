# A Simple MapKit Demo to demonstrate how to annotate and draw shapes on maps

For the full tutorial, please refer to this link:

http://www.appcoda.com/mapkit-beginner-guide/
